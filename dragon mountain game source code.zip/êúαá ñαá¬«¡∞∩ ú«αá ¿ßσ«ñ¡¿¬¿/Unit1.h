//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.Buttons.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Graphics.hpp>
#include <Vcl.Menus.hpp>
#include <Vcl.Imaging.pngimage.hpp>
#include <Vcl.Dialogs.hpp>
#include <Vcl.ExtDlgs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TImage *background;
	TBitBtn *B2;
	TBitBtn *B3;
	TButton *Start;
	TPanel *Panel1;
	TBitBtn *B1;
	TBitBtn *B5;
	TBitBtn *B4;
	TPanel *Panel2;
	TImage *Pobeda;
	TButton *Rabota;
	void __fastcall B1Click(TObject *Sender);
	void __fastcall B2Click(TObject *Sender);
	void __fastcall B3Click(TObject *Sender);
	void __fastcall B4Click(TObject *Sender);
	void __fastcall B5Click(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall StartClick(TObject *Sender);
	void __fastcall Panel2Click(TObject *Sender);
	void __fastcall PobedaClick(TObject *Sender);

private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};

//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
